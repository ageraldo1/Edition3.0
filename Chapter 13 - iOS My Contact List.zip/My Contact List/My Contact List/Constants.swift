//
//  Constants.swift
//  My Contact List
//
//  Created by Michael Eierman on 8/6/19.
//  Copyright © 2019 Learning Mobile Apps. All rights reserved.
//

import Foundation
struct Constants  {
    static let kSortField = "sortField"
    static let kSortDirectionAscending = "sortDirectionAscending"
}
